package main

import (
	"log"
	"net/http"
	"qrapi/api"
)

func main() {
	//tools.Generate_QRcode("https://www.weibo.com")
	http.HandleFunc("/", api.Response)
	http.HandleFunc("/test", api.Request_URL)
	//http.HandleFunc("/images",)
	log.Println("Running at [:8080]")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
